<?php
// close the mysql connection

mysql_close($conn);
?>