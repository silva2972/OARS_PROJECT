<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'some_password';
$dbname = 'ImageDB';
?>