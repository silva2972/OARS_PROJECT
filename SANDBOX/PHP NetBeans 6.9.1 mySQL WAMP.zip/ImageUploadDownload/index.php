<?php
header("Location: http://localhost/ImageUploadDownload/upload.php");
?>