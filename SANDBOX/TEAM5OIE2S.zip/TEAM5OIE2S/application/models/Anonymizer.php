<?php

//UC3 AnonymizeBeforeUploadEvarData (Refer to Sandbox Controller)
//Coded By: Chirag Ghanshani
//Date Created: 04/22/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

class Anonymizer
{
    
}

?>
