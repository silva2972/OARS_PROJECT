<?php

//UC5 UCUploadzipAnonymizedPatientLocaltoServerEVARData UC6 UnzipUploadPatientEvarData
//Coded By: Marden Benoit, Linh Ty
//Date Created: 04/23/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

class Zip_File_Uploader
{
    private $successfulDir = array();

    function UploadToServer($fn)
    {
         $viewInfo = array();
         $fileResults = "";
         $buttonMessage = "Upload More";
         if ($fn) {
            // AJAX call
            file_put_contents(
                    "D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\" . $fn,
                    file_get_contents('php://input')
            );
            exit();
        } else {
            // form submit
            $files = $_FILES['fileselect'];
            //Create tmp folder if it does not already exist
            if(!file_exists("D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp"))
            {
                mkdir("D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp");
            }

            foreach ($files['error'] as $id => $err) {
                if ($err == UPLOAD_ERR_OK) {
                    $fn = $files['name'][$id];
                    $zipFileType = pathinfo($fn,PATHINFO_EXTENSION);

                   if($zipFileType == "zip")
                   {
                     //File Type confirmed to be zip
                     if(move_uploaded_file($files['tmp_name'][$id], "D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\" . $fn))
                     {
                         array_push($this->successfulDir, "D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\" . $fn);
                         $fileResults .= "<p>";
                         $fileResults .= $fn . " has been uploaded successfully.";
                     }
                     else
                     {
                         $fileResults .= "<p>";
                         $fileResults .= $fn . " has failed to upload.";
                         $buttonMessage = "Try Again";
                     }
                   }
                   else
                   {
                       $fileResults .= "<p>";
                       $fileResults .= $fn . " is not a zip file. Upload failed.";
                       $buttonMessage = "Try Again";
                   }
                   //If file is not a zip go to failed to upload page.
                }
            }

        }
        array_push($viewInfo, $fileResults, $buttonMessage);
        return $viewInfo;
    }

    function GetSuccessfulDirectories()
    {
        return $this->successfulDir;
    }
}
?>
