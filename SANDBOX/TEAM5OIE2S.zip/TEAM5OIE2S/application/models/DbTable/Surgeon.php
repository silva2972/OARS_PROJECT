<?php
//UC1 Register
//Coded By: Jared Jones, Jeff Phan, Chad Van Roekel
//Date Created: 04/17/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit
class Application_Model_DbTable_Surgeon extends Zend_Db_Table_Abstract
{

    protected $_name = 'surgeon';
    private $salt = "gaysd9S(*D(f9g!@5926";

    private $_auditDB = null;

    public function init()
    {
        $this->_auditDB = new Application_Model_DbTable_Audit();
    }

    // Jared P. Jones (team5-5)
    // 04/21/2015 @ 12:04PM
    function UsernameAndPasswordValidate($user, $pass)
    {
        $md5_pass_salt = $this->GrabSaltedPassword($pass);

        $row = $this->fetchRow("`USER_NAME`='".$user."' AND `PASSWORD`='".$md5_pass_salt."'");

        $this->_auditDB->CreateAudit("-1", "visitor", "surgeon", "USER_NAME, PASSWORD", "SELECT");

        if (!$row)
            return false;
        else
            return true;
    }

    // Jared P. Jones (team5-5)
    // 04/21/2015 @ 12:20PM

    function GrabFirstName($user)
    {
        $row = $this->fetchRow("`USER_NAME`='".$user."'");

         $this->_auditDB->CreateAudit($this->GrabAccountID($user), $user, "surgeon", "FIRST_NAME", "SELECT");

        return $row["FIRST_NAME"];
    }

    function GrabLastName($user)
    {
        $row = $this->fetchRow("`USER_NAME`='".$user."'");

        $this->_auditDB->CreateAudit($this->GrabAccountID($user), $user, "surgeon", "LAST_NAME", "SELECT");

        return $row["LAST_NAME"];
    }

    function GrabAccountID($user)
    {
        $row = $this->fetchRow("`USER_NAME`='".$user."'");
        $id = $row["ID_SURGEON"];

        $this->_auditDB->CreateAudit($id, $user, "surgeon", "ID_SURGEON", "SELECT");

        return $id;
    }

    function GrabSaltedPassword($pass)
    {
        return md5($pass . $this->salt);
    }

    function CreateAccount($firstname, $lastname, $email, $username, $password, $institution)
    {
        $md5_password_salted = $this->GrabSaltedPassword($password);
        $this->getAdapter()->query("INSERT INTO surgeon (`FIRST_NAME`, `LAST_NAME`, `USER_NAME`, `PASSWORD`, `EMAIL`, `INSTITUTION_ID`) VALUES (\"" . $firstname . "\", \"" . $lastname . "\",\"" . $username . "\",\"" . $md5_password_salted . "\",\"" . $email . "\",\"" . $institution . "\");");
    
        $this->_auditDB->CreateAudit(-1, "visitor", "surgeon", "FIRST_NAME, LAST_NAME, USER_NAME, PASSWORD, EMAIL, INSTITUTION_ID", "INSERT");
    }

}

