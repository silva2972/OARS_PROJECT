<?php

class Application_Model_DbTable_Study extends Zend_Db_Table_Abstract
{

    protected $_name = 'study';


    private $_auditDB = null;
    private $_aM = null;

    public function init()
    {
        $this->_aM = new AccountManager();
        $this->_auditDB = new Application_Model_DbTable_Audit();
    }


    function AddStudy($studyDescription,$studyDate)
    {
        $this ->getAdapter() ->query("INSERT INTO study (`STDY_DESCRIPTION`,`STUDY_DATE`) VALUES (\"".$studyDescription."\",\"".$studyDate."\");");
//        if ($this->_aM->LoggedIn())
//            $this->_auditDB->CreateAudit($this->_aM->AccountID(), $this->_aM->Username(), "study", "CONTENT, ID_SURGEON", "INSERT");
//        else
//            $this->_auditDB->CreateAudit("-1", "visitor", "testimonial", "CONTENT, ID_SURGEON", "INSERT");
    }
    function studyExist($id)
    {
        $row = $this->fetchRow("`ORIGINAL_STDY_ID`='".$id."'");

        if (!$row)
            return false;
        else
            return true;
    }
    function GetPatientID($id)
    {
        $row = $this->fetchRow("`ORIGINAL_STDY_ID`='".$id."'");
        return $row["ID_PATIENT"];
    }

    function GetStudyID($id)
    {
        $row = $this->fetchRow("`ORIGINAL_STDY_ID`='".$id."'");
        return $row["ID_STUDY"];
    }

    function GetOriginalStudyID($id)
    {
        $row = $this->fetchRow("`ID_STUDY`='".$id."'");
        return $row["ORIGINAL_STDY_ID"];
    }


    function GetDate($id)
    {
        $row = $this->fetchRow("`ORIGINAL_STDY_ID`='".$id."'");
        return $row["STUDY_DATE"];
    }

    function GetCT($id)
    {
        $row = $this->fetchRow("`ORIGINAL_STDY_ID`='".$id."'");
        return $row["CT"];
    }
    function GetDelay($id)
    {
        $row = $this->fetchRow("`ORIGINAL_STDY_ID`='".$id."'");
        return $row["DELAY"];
    }
    function GetStudies($id)
    {
        $studies = array();
        $rowset = $this->fetchAll("`ID_PATIENT`='".$id."'");

        foreach($rowset as $row)
        {
            array_push($studies, $row['ORIGINAL_STDY_ID']);
        }

        return $studies;

    }
}

