<?php
//UC14 UCAddTestimonial UC15 UCSearchTestimonial
//Coded By: Jared Jones, Tim Dickson
//Date Created: 04/17/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit



class Application_Model_DbTable_Testimonial extends Zend_Db_Table_Abstract
{
    protected $_name = 'Testimonial';

    private $_auditDB = null;
    private $_aM = null;

    public function init()
    {
        $this->_aM = new AccountManager();
        $this->_auditDB = new Application_Model_DbTable_Audit();
    }

    function GrabArrayOfRowElement($col, $q, $count)
    {
        $arrayContents = $this->fetchAll($q, "ID_TESTIMONIAL DESC", $count);
        $finalArray = array();
        foreach ($arrayContents as $row)
        {
            array_push($finalArray, $row[$col]);
        }

        if ($this->_aM->LoggedIn())
            $this->_auditDB->CreateAudit($this->_aM->AccountID(), $this->_aM->Username(), "testimonial", $col, "SELECT");
        else
            $this->_auditDB->CreateAudit("-1", "visitor", "testimonial", $col, "SELECT");

        return $finalArray;
    }

    function AddTestimonial($testText, $surgeonID)
    {
        $this->getAdapter()->query("INSERT INTO testimonial (`CONTENT`, `ID_SURGEON`) VALUES (\"" . $testText . "\", " . $surgeonID . ");");
        if ($this->_aM->LoggedIn())
            $this->_auditDB->CreateAudit($this->_aM->AccountID(), $this->_aM->Username(), "testimonial", "CONTENT, ID_SURGEON", "INSERT");
        else
            $this->_auditDB->CreateAudit("-1", "visitor", "testimonial", "CONTENT, ID_SURGEON", "INSERT");
    }
}

