<?php

class Application_Model_DbTable_Image extends Zend_Db_Table_Abstract
{

    protected $_name = 'image';

    private $_auditDB = null;
    private $_aM = null;

    public function init()
    {
        $this->_aM = new AccountManager();
        $this->_auditDB = new Application_Model_DbTable_Audit();
    }


    function AddImage($filename,$pixelSize,$sliceThickness)
    {
        $this->getAdapter()->query("INSERT INTO image (`IMAGE_FILE_NAME`, `IMAGE_TITLE`,`PIXEL_SIZE`,`SLICE_THICKNESS`) VALUES (\"" . $filename . "\", \"" . $filename . "\", \"" . $pixelSize . "\" , \"" . $sliceThickness . "\");");
        // if ($this->_aM->LoggedIn())
        //     $this->_auditDB->CreateAudit($this->_aM->AccountID(), $this->_aM->Username(), "testimonial", "CONTENT, ID_SURGEON", "INSERT");
        // else
        //     $this->_auditDB->CreateAudit("-1", "visitor", "testimonial", "CONTENT, ID_SURGEON", "INSERT");
   
    }    

}

