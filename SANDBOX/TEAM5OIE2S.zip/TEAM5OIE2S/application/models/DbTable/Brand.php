<?php 

class Application_Model_DbTable_Brand extends Zend_Db_Table_Abstract
{

    protected $_name = 'brand';

    private $_dB = null;
    private $_auditDB = null;

    public function init()
    {
    	$this ->_dB = new AccountManager();
    	$this ->_auditDB = new Application_Model_DbTable_Audit();

    }
    
    function AddBrand($manufacturerModelName)
    {
    	$this->getAdapter()->query("INSERT INTO brand (`BRAND_NAME`) VALUES ('".$manufacturerModelName."');");
    
//    	if ($this->_dB->LoggedIn())
//    		$this->_auditDB->CreateAudit($this->_dB->AccountID(), $this->_aM->Username(), "testimonial", "CONTENT, ID_SURGEON", "INSERT");
//    	else
//    		$this->_auditDB->CreateAudit("-1", "visitor", "testimonial", "CONTENT, ID_SURGEON", "INSERT");
    }

}

