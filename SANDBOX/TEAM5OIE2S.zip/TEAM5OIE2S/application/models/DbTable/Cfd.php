<?php
//Adding CFD information to database
//Coded By: Jared Jones
//Date Created: 04/24/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit
class Application_Model_DbTable_Cfd extends Zend_Db_Table_Abstract
{

    protected $_name = 'cfd';

    function InsertIntoCFD($pID)
    {
        $this->getAdapter()->query("INSERT INTO cfd (`DONE`,`patientID`) VALUES ('" . 1 . "','" . $pID . "');");
    }

}
