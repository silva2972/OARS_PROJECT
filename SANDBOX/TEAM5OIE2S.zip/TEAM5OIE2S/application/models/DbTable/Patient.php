<?php
//Coded by: Chad Van Roekel
class Application_Model_DbTable_Patient extends Zend_Db_Table_Abstract
{

    protected $_name = 'patient';

    private $_auditDB = null;
    private $_aM = null;

    public function init()
    {
        $this->_aM = new AccountManager();
        $this->_auditDB = new Application_Model_DbTable_Audit();
    }

    function PatientExist($id)
    {
        $row = $this->fetchRow("`ORIGINAL_ID`='".$id."'");

        if (!$row)
            return false;
        else
            return true;
    }

    function SourceID($id)
    {
        $row = $this->fetchRow("`ORIGINAL_ID`='".$id."'");
        return $row["ID_PATIENT"];
    }

    function GetSex($id)
    {
        $row = $this->fetchRow("`ORIGINAL_ID`='".$id."'");
        return $row["SEX"];
    }

    function GetAge($id)
    {
        $row = $this->fetchRow("`ORIGINAL_ID`='".$id."'");
        return $row["AGE"];
    }
    
    function GetPatientID($id)
    {
        $row = $this->fetchRow("`ORIGINAL_ID`='".$id."'");
        return $row["ID_PATIENT"];
    }

    function GetOriginalID($id)
    {
        $row = $this->fetchRow("`ID_PATIENT`='".$id."'");
        return $row["ORIGINAL_ID"];
    }


    function AddPatient($patientNumber,$patientSex,$patientAge,$scanDate)
    {
    	$this ->getAdapter() ->query("INSERT INTO patient (`ORIGINAL_ID`,`SEX`,`AGE`,`ENTRY_DATE`) VALUES (\"".$patientNumber."\",\"".$patientSex."\",\"".$patientAge."\",\"".$scanDate."\");");
//        if ($this->_aM->LoggedIn())
//            $this->_auditDB->CreateAudit($this->_aM->AccountID(), $this->_aM->Username(), "testimonial", "CONTENT, ID_SURGEON", "INSERT");
//        else
//            $this->_auditDB->CreateAudit("-1", "visitor", "testimonial", "CONTENT, ID_SURGEON", "INSERT");
    }

}

