<?php

class Application_Model_DbTable_Series extends Zend_Db_Table_Abstract
{

    protected $_name = 'series';

    private $_auditDB = null;
    private $_aM = null;

    public function init()
    {
        $this->_aM = new AccountManager();
        $this->_auditDB = new Application_Model_DbTable_Audit();
    }

        function AddSeries($seriesID,$studyDate)
    {
        $this ->getAdapter() ->query("INSERT INTO series (`ORIGINAL_ID`,`ENTRY_DATE`) VALUES (\"".$seriesID."\",\"".$studyDate."\");");
        // if ($this->_aM->LoggedIn())
        //     $this->_auditDB->CreateAudit($this->_aM->AccountID(), $this->_aM->Username(), "testimonial", "CONTENT, ID_SURGEON", "INSERT");
        // else
        //     $this->_auditDB->CreateAudit("-1", "visitor", "testimonial", "CONTENT, ID_SURGEON", "INSERT");
    
    }

    function seriesExist($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");

        if (!$row)
            return false;
        else
            return true;
    }
    function GetStudyID($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["ID_STUDY"];
    }

    function GetSeriesID($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["ID_SERIES"];
    }

    function GetTotalSlices($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["TOTAL_NUM_OF_SLICES"];
    }

    function GetThickness($id)
    {
        //$row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        //return $row["CT"];
        return 0;
    }
    function GetPixelSize($id)
    {
        //$row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        //return $row["DELAY"];
        return 0;
    }
    function GetComments($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["COMMENTS"];
    }
    function GetSeries($id)
    {
        $series = array();
        $rowset = $this->fetchAll("`ID_STUDY`='".$id."'");

        foreach($rowset as $row)
        {
            array_push($series, $row['ORIGINAL_SER_ID']);
        }

        return $series;

    }
    function GetROIBegin($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["ROI_BEGIN"];
    }

    function GetIliacBif($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["ILLIAC_BIF"];
    }

    function GetROIEnd($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["ROI_END"];
    }

    function GetTotalSlides($id)
    {
       // $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        //return $row["COMMENTS"];
        return 0;
    }

    function GetROILength($id)
    {
        $row = $this->fetchRow("`ORIGINAL_SER_ID`='".$id."'");
        return $row["LENGTH_ROI_IN_CM"];
    }

    function UpdateComment($comment, $seid)
    {
        //UPDATE `team5oie2s`.`series` SET `COMMENTS` = 'as5' WHERE `series`.`ID_SERIES` = 1;
        $this->getAdapter()->query("UPDATE series SET `COMMENTS` = '" . $comment . "' WHERE `ORIGINAL_SER_ID` = '". $seid . "';");
    }
}

