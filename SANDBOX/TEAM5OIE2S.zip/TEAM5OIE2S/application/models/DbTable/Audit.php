<?php

class Application_Model_DbTable_Audit extends Zend_Db_Table_Abstract
{

    protected $_name = 'audit';

    function CreateAudit($uid, $username, $table, $attribute, $access)
    {
        $this->getAdapter()->query("INSERT INTO audit (`USERID_AUDIT`,`USERNAME`, `TABLE`, `ATTRIBUTE`, `ACCESS`) VALUES ('" . $uid . "','" . $username . "','" . $table . "','" . $attribute . "','" . $access . "');");
    }

    function SelectRows($numRows, $page)
    {
        $aM = new AccountManager();
        $this->CreateAudit($aM->AccountID(), $aM->Username(), "audit", "USERID_AUDIT,USERNAME,DATE,TABLE,ATTRIBUTE,ACCESS", "SELECT");
        $start = ($page - 1) * $numRows;

        $arrayContents = $this->getAdapter()->fetchAll("SELECT * FROM audit ORDER BY DATE DESC LIMIT " . $start . "," . ($numRows + $start) . ";");
        return $arrayContents;
    }

    function NumberofRows()
    {
        $aM = new AccountManager();
        $this->CreateAudit($aM->AccountID(), $aM->Username(), "audit", "USERID_AUDIT", "SELECT");
        $contents = $this->getAdapter()->fetchAll("SELECT COUNT(*) AS ID_AUDIT FROM audit;");
        foreach ($contents as $row)
        {
            return $row['ID_AUDIT'];
        }
    }

}

