<?php
//Endograft to Database
//Coded By: Linh Ty
//Date Created: 04/24/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit
class Application_Model_DbTable_Endograft extends Zend_Db_Table_Abstract
{

    protected $_name = 'endograft';

    function addEndograph($dia,$len,$uniDiameter,$uniLength,$contDiameter,$contLength,$entry,$primID,$patientID,$brandID)
    {
    	$this->getAdapter()->query("INSERT INTO endograft (`DIAMETER`,`LENGTH`,`UNI_LAT_LEG_DIAM`,`UNI_LAT_LEG_LENGTH`,`CONT_LAT_LEG_DIAM`,`CONT_LAT_LEG_LENGTH`,`ENTRY_POINT`,`ID_PRIMARY`,`ID_PATIENT`,`BRAND_ID`) VALUES ('" . $dia . "','" . $len . "','" . $uniDiameter . "','" . $uniLength . "','" . $contDiameter . "','" . $contLength . "','" . $entry . "','" . $primID . "','" . $patientID . "','" . $brandID . "');");
    }

}
