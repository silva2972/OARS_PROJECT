<?php

require(dirname(__DIR__) . "/models/PHPMailer/PHPMailerAutoload.php");

class Email {

    public function SendEmail($to, $subject, $body) {

        $mail = new PHPMailer(); // defaults to using php "mail()"

        $mail->IsSMTP();                       // telling the class to use SMTP

        $mail->SMTPDebug = 0;
// 0 = no output, 1 = errors and messages, 2 = messages only.

        $mail->SMTPAuth = true;                // enable SMTP authentication 
        $mail->SMTPSecure = "tls";              // sets the prefix to the servier
        $mail->Host = "smtp.gmail.com";        // sets Gmail as the SMTP server
        $mail->Port = 587;                     // set the SMTP port for the GMAIL

        $mail->Username = "team5oie2s@gmail.com";
        $mail->Password = "cosc4351";

        

        $mail->AddReplyTo("team5oie2s@gmail.com", "TEAM5OIE2S Mailer");
        $mail->SetFrom("team5oie2s@gmail.com", "TEAM5OIE2S Mailer");

        $address = $to;
        $mail->AddAddress($address, "Jared Jones");

        $mail->Subject = $subject;

        $mail->AltBody = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

        $mail->MsgHTML($body);

        if (!$mail->Send()) {
            //echo "Mailer Error: " . $mail->ErrorInfo;
            return 1;
        } else {


            //echo "Message sent!";
            return 0;
        }
    }
}
?>
