<?php

//Bootstrap run
//Coded By: Jared Jones
//Date Created: 04/18/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{


}

