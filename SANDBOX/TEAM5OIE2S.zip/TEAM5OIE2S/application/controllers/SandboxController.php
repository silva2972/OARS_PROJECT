<?php

//Sandbox (Testing php file)
//Created By: Jared Jones
//Coded By: Chirag Ghanshani
//Date Created: 04/17/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

require(dirname(__DIR__) . "/models/class_dicom.php");
require(dirname(__DIR__) . "/models/AccountManager.php");
require(dirname(__DIR__) . "/models/Email.php");

function rrmdir($dir) {
   if (is_dir($dir)) {
     $objects = scandir($dir);
     foreach ($objects as $object) {
       if ($object != "." && $object != "..") {
         if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object);
       }
     }
     reset($objects);
     rmdir($dir);
   }
   echo "<h1>" . $dir . " Deleted!</h1><br>";
   }

function mailAction() {
        $m = new Email();
        $m->SendEmail("jjones@uvora.com", "Hello World", "Whaddup?");
    }

class SandboxController extends Zend_Controller_Action {

    private $_aM = null;

    public function init() {
        /* Initialize action controller here */
        session_start();
        $this->_aM = new AccountManager();
        $loggedIn = $this->_aM->LoggedIn();

        //If not logged in we can't view this page
        if (!$loggedIn) {
            header("location: " . $this->view->baseURL() . "/index");
            exit();
        }
    }

    //Chirag's Code
    public function indexAction() {

//        $zip = new ZipArchive();

        $tag_names = array('0010,0010' => 'NAME^NONE',
            '0010,1040' => 'NONE^NONE'
        );
  //      $key = "C:\\wamp\\www\\dicomDest\\DICOM\\";


  //      $filename = new dicom_tag;
    //    $handle = opendir('C:\\wamp\\www\\dicomDest\\DICOM\\');
      //  while (false !== ($file = readdir($handle))) {
//            if($file != '.' && $file != '..'){
  //              echo  $key.$file . "<br>";
    //            $filename->file = $key.$file;
      //          $filename->load_tags();
        //        print($filename->get_tag('0010','0010'));
          //      break;
//            }
        }

        /*
          $files = glob($key);

          foreach($files as $file){
          echo ":". $file . "<br>";

          }
         */


        /* foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator('C:\wamp\www\dicomDest\DICOM')) as $filename->file){
          $filename->file = $filename->write_tags($tag_names);
          print $filename->file;
          } */
    //}

    //end Chirag's Code

    public function debugAction() {
        mkdir("d:/COSC4351_Spring2015/TEAM5OIE2S/tmp");
        echo phpinfo();
    }

    public function listDirectoryAction() {
        // action body
        if (isset($_POST["deletetmp"])) {
            rrmdir("d:/COSC4351_Spring2015/TEAM5OIE2S/tmp");
        }

        echo "<h1>Files/Folder in TEAM5OIE2S</h1>";
        echo "<hr>";

        // Create recursive dir iterator which skips dot folders
        $dir = new RecursiveDirectoryIterator("d:/COSC4351_Spring2015/TEAM5OIE2S",
                        FilesystemIterator::SKIP_DOTS);

        // Flatten the recursive iterator, folders come before their files
        $it = new RecursiveIteratorIterator($dir,
                        RecursiveIteratorIterator::SELF_FIRST);

        // Maximum depth is 5 levels deeper than the base folder
        $it->setMaxDepth(5);

        // Basic loop displaying different messages based on file or folder
        foreach ($it as $fileinfo) {
            if ($fileinfo->isDir()) {
                printf("Folder: %s<br>", $fileinfo->getFilename());
            } elseif ($fileinfo->isFile()) {
                printf("----:File From %s - %s<br>", $it->getSubPath(), $fileinfo->getFilename());
            }
        }

        echo "<form action=\"list-directory\" method=\"POST\"><input type = \"submit\" value=\"Delete TMP Folder\"/><input hidden type=\"text\" name=\"deletetmp\" value=\"deletetmp\"/></form>";
    }

}

