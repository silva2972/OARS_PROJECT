<?php

//UC1 Register (Refer to AccountController.php)
//Coded By: Jared Jones, Chad Van Roekel
//Date Created: 04/24/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

require(dirname(__DIR__) . "/models/AccountManager.php");
class RegisterController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // action body
    }


}

?>
