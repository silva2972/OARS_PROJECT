<?php

//Contact Us
//Coded By: Jared Jones
//Date Created: 04/21/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

require(dirname(__DIR__) . "/models/AccountManager.php");
class ContactController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        session_start();
        $this->_aM = new AccountManager();

        $loggedIn = $this->_aM->LoggedIn();
        if ($loggedIn)
        {
            $fname = $this->_aM->firstName();
            $lname = $this->_aM->lastName();
            $this->view->LoggedInView = "Welcome Dr. " . $fname . " " . $lname . " | <a href=" . $this->view->baseURL() . "/account/logout>Logout</a>";
            $this->view->NavbarExtra = "<a href=" . $this->view->baseURL() . "/upload-file>Upload Dicom</a>" . "
                <a href=" . $this->view->baseURL() . "/data-analysis>Data Analysis</a>";
        }
        else
        {
            $this->view->LoggedInView = "<a href=" . $this->view->baseURL() . "/account>Login | Register</a>";
            $this->view->NavbarExtra = "";
        }
    }

    public function indexAction()
    {
        // action body
    }


}

