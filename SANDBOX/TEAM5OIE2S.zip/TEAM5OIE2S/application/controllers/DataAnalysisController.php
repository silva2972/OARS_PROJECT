<?php

//UC9 Data Analysis
//Coded By: Chad Van Roekel
//Date Created: 04/21/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

require(dirname(__DIR__) . "/models/AccountManager.php");

class DataAnalysisController extends Zend_Controller_Action
{
    private $_pA = null;

    public function init()
    {
        session_start();
        $this->_aM = new AccountManager();

        $loggedIn = $this->_aM->LoggedIn();

        //If not logged in we can't view this page
        if (!$loggedIn)
        {
            header("location: " . $this->view->baseURL() . "/index");
            exit();
        }

        if ($loggedIn)
        {
            $fname = $this->_aM->firstName();
            $lname = $this->_aM->lastName();
            $this->view->LoggedInView = "Welcome Dr. " . $fname . " " . $lname . " | <a href=" . $this->view->baseURL() . "/account/logout>Logout</a>";
            $this->view->NavbarExtra = "<a href=" . $this->view->baseURL() . "/upload-file>Upload Dicom</a>" . "
                <a href=" . $this->view->baseURL() . "/data-analysis>Data Analysis</a>";
        }
        else
        {
            $this->view->LoggedInView = "<a href=" . $this->view->baseURL() . "/account>Login | Register</a>";
            $this->view->NavbarExtra = "";
        }
        /* Initialize action controller here */

    }

    public function indexAction()
    {
        $id;
        $sid;
        //FILL FORM
        if(isset($_POST['patientID'])) //&& isset($_POST['studyID']) && isset($_POST['seriesID']) && isset($_POST['ROIBegin']) && isset($_POST['IliacBif']))
        {
            $this->_pA = new Application_Model_DbTable_Patient();
            $this->_sT = new Application_Model_DbTable_Study();

            $id = $_POST['patientID'];
            
            if ($this->_pA->PatientExist($id))
            {
                $this->view->PatientNumberView = $id;
                $this->view->PatientAgeView = $this->_pA->GetAge($id);
                $this->view->PatientSexView = $this->_pA->GetSex($id);
                $this->view->CTSelectView = $this->_sT->GetStudies($id);

                $html = "";

                $studArr = $this->_sT->GetStudies($this->_pA->GetPatientID($id));
                foreach ($studArr as $elem){
                    $html .= "<option>";
                    $html .= $elem;
                    $html .= "</option>";
                }
                $this->view->StudyDropdownView = $html;
            }
            else
            {
                $this->view->PatientNumberView = "NAN";
                $this->view->PatientAgeView = "NAN";
                $this->view->PatientSexView = "NAN";
            }


        }
        if(isset($_POST['CT_select']))
        {
            $this->_pA = new Application_Model_DbTable_Patient();
            $this->_sT = new Application_Model_DbTable_Study();
            $this->_sE = new Application_Model_DbTable_Series();
            
            $sid = $_POST['CT_select'];

            if ($this->_sT->StudyExist($sid))
            {
                $id = $this->_pA->GetOriginalID($this->_sT->GetPatientID($sid));

                $this->view->PatientNumberView = $id;
                $this->view->PatientAgeView = $this->_pA->GetAge($id);
                $this->view->PatientSexView = $this->_pA->GetSex($id);
                $this->view->StudyDateView = $this->_sT->GetDate($sid);
                $this->view->StudyCTView = $this->_sT->GetCT($sid);
                $this->view->StudyDelayView = $this->_sT->GetDelay($sid);

                $html = "";

                $serArr = $this->_sE->GetSeries($this->_sT->GetStudyID($sid));
                foreach ($serArr as $elem){
                    $html .= "<option>";
                    $html .= $elem;
                    $html .= "</option>";
                }
                $this->view->SeriesDropdownView = $html;
                

            }
            else
            {
                $this->view->PatientNumberView = "NAN";
                $this->view->PatientAgeView = "NAN";
                $this->view->PatientSexView = "NAN";
            }
        }
        if(isset($_POST['Series_select']))
        {
            $this->_pA = new Application_Model_DbTable_Patient();
            $this->_sT = new Application_Model_DbTable_Study();
            $this->_sE = new Application_Model_DbTable_Series();
            
            $seid = $_POST['Series_select'];
            $seriesid = $seid;

            if ($this->_sE->SeriesExist($seid))
            {
                $sid = $this->_sT->GetOriginalStudyID($this->_sE->GetStudyID($seid));
                $id = $this->_pA->GetOriginalID($this->_sT->GetPatientID($sid));

                $this->view->PatientNumberView = $id;
                $this->view->PatientAgeView = $this->_pA->GetAge($id);
                $this->view->PatientSexView = $this->_pA->GetSex($id);

                $this->view->StudyDateView = $this->_sT->GetDate($sid);
                $this->view->StudyCTView = $this->_sT->GetCT($sid);
                $this->view->StudyDelayView = $this->_sT->GetDelay($sid);

                $this->view->TotalSlicesView = $this->_sE->GetTotalSlices($seid);
                $this->view->ThicknessView = $this->_sE->GetThickness($seid);
                $this->view->PixelSizeView = $this->_sE->GetPixelSize($seid);
                $this->view->ROIBeginView = $this->_sE->GetROIBegin($seid);
                $this->view->IliacBifView = $this->_sE->GetIliacBif($seid);
                $this->view->ROIEndView = $this->_sE->GetROIEnd($seid);
                $this->view->TotalSlidesView = $this->_sE->GetTotalSlides($seid);
                $this->view->ROILengthView = $this->_sE->GetROILength($seid);
                $this->view->CommentsView = $this->_sE->GetComments($seid);


            }
            else
            {
                $this->view->PatientNumberView = "NAN";
                $this->view->PatientAgeView = "NAN";
                $this->view->PatientSexView = "NAN";
            }
        }

    }
}

