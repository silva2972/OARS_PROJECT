<?php

require(dirname(__DIR__) . "/models/AccountManager.php");

class AuditController extends Zend_Controller_Action
{

    public function init()
    {
        session_start();
        $this->_aM = new AccountManager();
        $loggedIn = $this->_aM->LoggedIn();

        //If not logged in we can't view this page
        if (!$loggedIn) {
            header("location: " . $this->view->baseURL() . "/index");
            exit();
        }

        if ($loggedIn) {
            $fname = $this->_aM->firstName();
            $lname = $this->_aM->lastName();
            $this->view->LoggedInView = "Welcome Dr. " . $fname . " " . $lname . " | <a href=" . $this->view->baseURL() . "/account/logout>Logout</a>";
            $this->view->NavbarExtra = "<a href=" . $this->view->baseURL() . "/upload-file>Upload Dicom</a>" . "
                <a href=" . $this->view->baseURL() . "/data-analysis>Data Analysis</a>";
        } else {
            $this->view->LoggedInView = "<a href=" . $this->view->baseURL() . "/account>Login | Register</a>";
            $this->view->NavbarExtra = "";
        }
        /* Initialize action controller here */

        $auditDB = new Application_Model_DbTable_Audit();
        $numRows = 50;
        $page = 1;

        if (isset($_GET['page']))
        {
            $page = $_GET['page'];
        }

        $result = $auditDB->SelectRows($numRows, $page);

        $html = "";

        foreach ($result as $row)
        {
            $html .= "<tr>";

            $html .= "<td style=\"font-size:12px;\">";
            $html .= $row["USERID_AUDIT"];
            $html .= "</td>";

            $html .= "<td style=\"font-size:12px;\">";
            $html .= $row["USERNAME"];
            $html .= "</td>";

            $html .= "<td style=\"font-size:12px;\">";
            $html .= $row["DATE"];
            $html .= "</td>";

            $html .= "<td style=\"font-size:12px;\">";
            $html .= $row["TABLE"];
            $html .= "</td>";

            $html .= "<td style=\"font-size:8px;\">";
            $html .= $row["ATTRIBUTE"];
            $html .= "</td>";

            $html .= "<td style=\"font-size:12px;\">";
            $html .= $row["ACCESS"];
            $html .= "</td>";

            $html .= "</tr>";
        }

        $this->view->TableContent = $html;

        $pageHTML = "";

        $numEntries =  $result = $auditDB->NumberofRows();
        $numPages = $numEntries / $numRows;

        for ($i = 0; $i < $numPages; $i++)
        {
            $pageHTML .= "[<a href=\"Audit?page=" . ($i + 1) . "\">" . ($i + 1) . "</a>]";
        }
        $this->view->Page = $pageHTML;
        $this->view->PageNum = $page;
    }

    public function indexAction()
    {
        // action body
    }


}

