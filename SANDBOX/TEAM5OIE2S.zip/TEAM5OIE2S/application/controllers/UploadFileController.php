<?php

//UC5 UploadzipAnonymizedPatientLocaltoServerEVARData
//Coded By: Marden Benoit, Linh Ty
//Date Created: 04/24/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

ini_set('upload_max_filesize', '7G');
ini_set('post_max_size', '7G');
ini_set('max_input_time', 3000);
ini_set('max_execution_time', 3000);
require(dirname(__DIR__) . "/models/AccountManager.php");

require(dirname(__DIR__) . "/models/Uploader.php");
require(dirname(__DIR__) . "/models/class_dicom.php");
require(dirname(__DIR__) . "/models/Email.php");



class UploadFileController extends Zend_Controller_Action {

    private $storage = null;

    private $_brandDB = null;
    private $_patientDB = null;
    private $_studyDB = null;
    private $_seriesDB = null;
    private $_imageDB = null;

    public function init() {


        //brand db manager
        $this->_brandDB = new Application_Model_DbTable_Brand();
        //patient db manager
        $this->_patientDB = new Application_Model_DbTable_Patient();
        //study db manager
        $this->_studyDB = new Application_Model_DbTable_Study();
        //series db manager
        $this->_seriesDB = new Application_Model_DbTable_Series();
        //image db manager
        $this->_imageDB = new Application_Model_DbTable_Image();

        $this->storage = new Zip_File_Uploader();
        $this->view->resultText = "";

        session_start();
        $this->_aM = new AccountManager();
        $loggedIn = $this->_aM->LoggedIn();

        //If not logged in we can't view this page
        if (!$loggedIn) {
            header("location: " . $this->view->baseURL() . "/index");
        }

        if ($loggedIn) {
            $fname = $this->_aM->firstName();
            $lname = $this->_aM->lastName();
            $this->view->LoggedInView = "Welcome Dr. " . $fname . " " . $lname . " | <a href=" . $this->view->baseURL() . "/account/logout>Logout</a>";
            $this->view->NavbarExtra = "<a href=" . $this->view->baseURL() . "/upload-file>Upload Dicom</a>" . "
                <a href=" . $this->view->baseURL() . "/data-analysis>Data Analysis</a>";
        } else {
            $this->view->LoggedInView = "<a href=" . $this->view->baseURL() . "/account>Login | Register</a>";
            $this->view->NavbarExtra = "";
        }
    }

    public function indexAction() {

    }

    public function submitAction() {
        $mailer = new Email();
        $mailer->SendEmail("team5oie2s@gmail.com", "Dicom Uploads/CFD Inserted", "Your DICOM files along with a CFD Row has been inserted into the database.");
        $dbHook = new Application_Model_DbTable_Cfd();
        $dbHook->InsertIntoCFD(18);

        // Endograph information being sent to database
        //$dia,$len,$uniDiameter,$uniLength,$contDiameter,$contLength,$entry,$primID,$patientID,$brandID
        
        $dbEndo = new Application_Model_DbTable_Endograft();
        $dbEndo->addEndograph($_POST['diameter1'],$_POST['length1'],$_POST['diameter2'],$_POST['length2'],$_POST['diameter3'],$_POST['length3'],$_POST['entry'],1,1,$_POST['brand']);
        
        /////////////////////////////////////////////////////////

        $fn = (isset($_SERVER['HTTP_X_FILENAME']) ? $_SERVER['HTTP_X_FILENAME'] : false);
        $uploadResultText = $this->storage->UploadToServer($fn);
        $this->view->resultText = $uploadResultText[0];
        $this->view->buttonText = $uploadResultText[1];

        //get directories of the files that were sucessfully uploaded
        $successfulUploads = $this->storage->GetSuccessfulDirectories();
        $this->unzipToAnonomize($successfulUploads);
    }

    public function unzipToAnonomize($zippedDirectories) {
        $zip = new ZipArchive();
        foreach ($zippedDirectories as $zipDirectory) {
            if ($zip->open($zipDirectory) === TRUE) {
                $zip->extractTo(pathinfo($zipDirectory, PATHINFO_DIRNAME));
                $zip->close();
                unlink($zipDirectory);
                //Dicom info is uploaded to database
                //$this->UCStoreinDatabaseEVARMetadata('D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\');
                //create dicom video
                //Delete dicom files
                /*
                  $fileIterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\", FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
                  foreach($fileIterator as $fileDirectory)
                  {
                  if(pathinfo($fileDirectory,PATHINFO_EXTENSION) != "mp4")
                  {
                  if(is_dir($fileDirectory))
                  {
                  rmdir($fileDirectory);
                  }
                  else
                  {
                  unlink($fileDirectory);
                  }
                  }
                  } */
            }
        }
    }

    //UCStoreinDatabaseEVARMetadata
    //created by: carlos
    //coded by: chirag
    //coded by: carlos
    //date approved:
    //approved by:



    public function UCStoreinDatabaseEVARMetadata($key) {
        $dicomExtractor = new dicom_tag;
        
        $patientID = 0;
        $patientSex = 'X';
        $patientAge = 0;
        $entryDate = 0;
        $studyID = 0;
        $handle = opendir($key);

        while (false !== ($file = readdir($handle))){
            if($file != '.' && $file != '..' && !is_dir($key.$file)){
                

                $extension = pathinfo($key.$handle);
                if(!isset($extension['extension'])){
                      $dicomExtractor->file = $key.$file;
                      $dicomExtractor->load_tags();
                      $patientID = $dicomExtractor->get_tag('0010', '0020');
                      $patientSex = $dicomExtractor->get_tag('0010', '0040');
                      $patientAge = $dicomExtractor->get_tag('0010', '1010');
                      $entryDate = $dicomExtractor->get_tag('0009', '1027');
                      $studyID = $dicomExtractor->get_tag('0020', '0010');

                }
            }
            else if($file != '.' && $file != '..' && is_dir($key.$file)){
                $this->UCStoreinDatabaseEVARMetadata($key.$file);
            }
        }
    }

       /* $this->_aM = new AccountManager();
        $key = "D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\";
        print "checking";
        //$fileIterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\", FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        $handle = opendir("D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\");
        print "checking";
        //$fileIterator =  new DirectoryIterator("D:\\COSC4351_Spring2015\\TEAM5OIE2S\\tmp\\");
        //foreach ($fileIterator as $filename) {
        while (false !== ($file = readdir($handle))) {
            if($file != '.' && $file != '..'){
            print "checking";
            print "<BR>";
            print $key.$file;
            print "<BR>";
            //extract image data from files
            $dicomExtractor = new dicom_tag($key.$file); // name of the file
            $dicomExtractor->load_tags();
            $sliceThickness = $dicomExtractor->get_tag('0018', '0050');
            $pixelSize = $dicomExtractor->get_tag('0028', '0030');
            $sliceSpacing = $dicomExtractor->get_tag('0018', '0088');
            $manufacturerModelName = $dicomExtractor->get_tag('0008', '1090');
            $manufacturer = $dicomExtractor->get_tag('0008', '0070');
            $institutionName = $dicomExtractor->get_tag('0008', '0080');

            //extract patient data from files:
            $patientSex = $dicomExtractor->get_tag('0010', '0040');
            $patientAge = $dicomExtractor->get_tag('0010', '1010');
            $scanDate = $dicomExtractor->get_tag('0008', '0022'); // acquisitionDate
            $patientNumber = $dicomExtractor->get_tag('0010', '0020');

            //getting study info
            $studyDescription = $dicomExtractor->get_tag('0008', '1030');
            $studyDate = $dicomExtractor->get_tag('0008', '0020');

            //getting series info
            $seriesID = $dicomExtractor->get_tag('0020', '0011');
            $seriesDate = $dicomExtractor->get_tag('0008', '0021');
            print($dicomExtractor->get_tag('0010', '0010'));


            //adding to the brand table:
            $this->getAdapter()->query("INSERT INTO brand (`BRAND_NAME`) VALUES (\"" . $manufacturerModelName . "\");");


            //still need study id
            //adding patient table
            $this->getAdapter()->query("INSERT INTO patient (`ORIGINAL_ID`,`SEX`,`AGE`,`ENTRY_DATE`) VALUES (\"" . $patientNumber . "\",\"" . $patientSex . "\",\"" . $patientAge . "\",\"" . $scanDate . "\");");


            //using the folder name as teh original study id, we also need ID_patient
            //dont know what to do with ct and delay and original study id
            //adding to study table
            $this->getAdapter()->query("INSERT INTO study (`STDY_DESCRIPTION`,`STUDY_DATE`) VALUES (\"" . $studyDescription . "\",\"" . $studyDate . "\");");


            //missing study id we can get this from the database. maybe matching for the id of the study just created
            //adding to series table
            $this->getAdapter()->query("INSERT INTO series (`ORIGINAL_ID`,`ENTRY_DATE`) VALUES (\"" . $seriesID . "\",\"" . $studyDate . "\");");



            //should be adding a new entry into the image table.
            // dont know difference  title and image file name.
            //dont know where im getting series from
            //adding to image table
            $this->getAdapter()->query("INSERT INTO image (`IMAGE_FILE_NAME`, `IMAGE_TITLE`,`PIXEL_SIZE`,`SLICE_THICKNESS`) VALUES (\"" . $filename . "\", \"" . $filename . "\", \"" . $pixelSize . "\" , \"" . $sliceThickness . "\");");
            }
        }
    }*/

}
