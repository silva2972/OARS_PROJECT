<?php

//UC14 AddTestimonial UC15 SearchTestimonial
//Coded By: Jared Jones, Tim Dickson
//Date Created: 04/19/2015
//Date Approved: 04/27/2015
//Approved By: Linh Ty, Marden Benoit

require(dirname(__DIR__) . "/models/AccountManager.php");
class TestimonialsController extends Zend_Controller_Action
{

    private $_DB = null;
    private $_aM = null;

    public function init()
    {
        $this->_DB = new Application_Model_DbTable_Testimonial();

        session_start();
        $this->_aM = new AccountManager();
        $loggedIn = $this->_aM->LoggedIn();

        $this->view->LoggedIn = $loggedIn;

        if ($loggedIn)
        {
            $fname = $this->_aM->firstName();
            $lname = $this->_aM->lastName();
            $this->view->LoggedInView = "Welcome Dr. " . $fname . " " . $lname . " | <a href=" . $this->view->baseURL() . "/account/logout>Logout</a>";
            $this->view->NavbarExtra = "<a href=" . $this->view->baseURL() . "/upload-file>Upload Dicom</a>" . "
                <a href=" . $this->view->baseURL() . "/data-analysis>Data Analysis</a>";
        }
        else
        {
            $this->view->LoggedInView = "<a href=" . $this->view->baseURL() . "/account>Login | Register</a>";
            $this->view->NavbarExtra = "";
        }
    }

    public function indexAction()
    {
        $this->view->IDViewElement = $this->CreateContentListOfColumn("ID_TESTIMONIAL", null, 10);
        $this->view->ContentViewElement = $this->CreateContentListOfColumn("CONTENT", null, 10);
        $this->view->DateViewElement = $this->CreateContentListOfColumn("DATE", null, 10);

        if(isset($_POST["searchID"]))
        {
            if (empty($_POST['name']))
            {
                $this->clearContentViews();
                return;
            }

            if (!is_numeric($_POST['name']))
            {
                $this->clearContentViews();
                return;
            }

            $idStr="ID_TESTIMONIAL=";
            $idStr .= $_POST['name'];
            $this->view->IDViewElement = $this->CreateContentListOfColumn("ID_TESTIMONIAL", $idStr, 1);
            $this->view->ContentViewElement = $this->CreateContentListOfColumn("CONTENT", $idStr, 1);
            $this->view->DateViewElement = $this->CreateContentListOfColumn("DATE", $idStr, 1);

        }
        else if (isset($_POST["searchKeyword"]))
        {
            if (empty($_POST['name']))
            {
                $this->clearContentViews();
                return;
            }

            $this->view->IDViewElement = $this->CreateContentListOfColumn("ID_TESTIMONIAL", "CONTENT LIKE '%" . $_POST['name'] . "%'", 200);
            $this->view->ContentViewElement = $this->CreateContentListOfColumn("CONTENT", "CONTENT LIKE '%" . $_POST['name'] . "%'", 200);
            $this->view->DateViewElement = $this->CreateContentListOfColumn("DATE", "CONTENT LIKE '%" . $_POST['name'] . "%'", 200);
        }
        else if (isset($_POST["searchDate"]))
        {
            if (empty($_POST['name']))
            {
                $this->clearContentViews();
                return;
            }

            $this->view->IDViewElement = $this->CreateContentListOfColumn("ID_TESTIMONIAL", "DATE LIKE '" . $_POST['name'] . "%'", 200);
            $this->view->ContentViewElement = $this->CreateContentListOfColumn("CONTENT", "DATE LIKE '" . $_POST['name'] . "%'", 200);
            $this->view->DateViewElement = $this->CreateContentListOfColumn("DATE", "DATE LIKE '" . $_POST['name'] . "%'", 200);
        }
        else if (isset($_POST["submitTestimonial"]))
        {
            $loggedIn = $this->_aM->LoggedIn();
            if (!$loggedIn)
                return;
            
            $testText = $_POST['testimonial-text'];
            if (empty($testText))
                return;
            
            if (ctype_space($testText))
                return;

            if (strlen($testText) > 47)
                return;

            $this->_DB->AddTestimonial($testText, $this->_aM->AccountID());

            //Refresh page after insert
            header("location:" . $this->view->baseURL() . "/testimonials");
        }
        // action body
    }

    private function clearContentViews()
    {
        $this->view->IDViewElement = "";
        $this->view->ContentViewElement = "";
        $this->view->DateViewElement = "";
    }

    public function CreateContentListOfColumn($str, $q, $count)
    {
        $arr = $this->_DB->GrabArrayOfRowElement($str, $q, $count);
        $finalHTML = "";
        foreach ($arr as $elem)
        {
            $finalHTML .= "<p>";
            $finalHTML .= $elem;
            $finalHTML .= "</p>";
        }
        return $finalHTML;
    }
}





